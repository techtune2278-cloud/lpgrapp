-- CONFIDENTIEL — données de référence reprises du classeur LPGR'APP.
-- À exécuter après les migrations 001 à 004 et après supabase/seed_catalog.sql.
-- Idempotent via source_legacy; les ventes et stocks historiques NE sont PAS transformés en opérations.
begin;

-- Attribuer l'import au premier compte existant pour que le journal d'audit ait un auteur identifiable.
DO $$ DECLARE v_id text; BEGIN SELECT id::text INTO v_id FROM auth.users WHERE lower(email)=lower('gaelvali@gmail.com') LIMIT 1; IF v_id IS NOT NULL THEN PERFORM set_config('request.jwt.claim.sub', v_id, true); END IF; END $$;

insert into public.contacts (name, contact_type, address, postal_code, city, email, phone, website, notes, source_legacy) values
('Actes Sud Jeunesse', 'editeur', NULL, NULL, NULL, 'sbenhamou@editions-thierry-magnier.com', NULL, NULL, 'Interlocuteur : Actes Sud Jeunesse / 62 avenue de Saxe / 75015 Paris; Prochaine action Excel : envoyer Sand ou Jules Verne (Amélie); Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:28db993430d747'),
('Adjointe au maire - Marché Montaut', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Salon / Marché', 'excel:reference-contact:6984b44cc1766d'),
('Agnès Triboulet', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:a5feab0bfbf1be'),
('Alexandre Meuli', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:39ef8540bf2585'),
('Alliance française de Toronto', 'association', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Alliance française', 'excel:reference-contact:c6cfefd40e1807'),
('APEL Saint-Joseph Pontrieux', 'ecole', NULL, NULL, NULL, NULL, NULL, NULL, 'Statut Excel : À contacter; Feuille source : écoles', 'excel:reference-contact:c33fdcf9d6ec15'),
('Arlequin', 'editeur', NULL, NULL, NULL, 'info@arlequineditions.com', '0758949450', 'https://arlequineditions.com/', 'Interlocuteur : Noël Canslère; Dernière action Excel : ok le 18/04/2026; Notes Excel : font des livres pour les enfants  de 0 à 5 ans/ on lui a donné un flyer , envoyer un mail; Prochaine action Excel : envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter; Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:7aed739991f2a3'),
('Armelle Lemoine', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Abonnement', 'excel:reference-contact:d4a5175bde5ebb'),
('Aurélie Boutboul', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:ed340af1373837'),
('Aurélie Cauche', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:81b96ffcc0ee88'),
('Babel Librairie', 'librairie', NULL, NULL, 'Plouha', NULL, NULL, NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:5bcbbaf2301c4d'),
('Camourakis', 'editeur', NULL, NULL, NULL, 'editions@cambourakis.com', NULL, 'https://www.cambourakis.com/', 'Prochaine action Excel : envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter; Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:54ed29c3576ef3'),
('Cécile Duché', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:0ac4a799272e77'),
('Client X - Marché Montaut', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Salon / Marché', 'excel:reference-contact:48090c15ad883f'),
('Clo Guérineau', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Abonnement', 'excel:reference-contact:1e57ecc7518216'),
('Comment dire', 'librairie', '5 rue Jules Simon', '35000', 'Rennes', 'info@librairiecommentdire.fr', '02 23 61 24 97', 'https://www.librairiecommentdire.fr/', 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:8d21bf76de049c'),
('Crédit Agricole', 'autre', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Autre', 'excel:reference-contact:26f837f6bc8e51'),
('Danser sous la Pluie', 'librairie', '9 rue des Cordeliers', '64000', 'Pau', 'librairie@dansersouslapluie.fr', '05 59 02 03 14', NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:63b667aab8b1bb'),
('Dominique Valla', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Abonnement', 'excel:reference-contact:e443278ced8a62'),
('École de Montaut', 'ecole', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : École', 'excel:reference-contact:5015edbb20d92c'),
('Ecole des Loisirs', 'editeur', NULL, NULL, NULL, 'edl@ecoledesloisirs.com', NULL, NULL, 'Interlocuteur : Comité de lecture 11 rue de  Sèvres 75006 Paris; Prochaine action Excel : envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter; Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:45071182135146'),
('École St Louis - Ste Thérèse', 'ecole', '25 rue de Malleville 95880 Enghien les bains', NULL, NULL, NULL, NULL, NULL, 'Interlocuteur : Madame Clémence Briand-Métairie; Dernière action Excel : envoi le 5/10/2026 comtesse, Molière et Verne par la poste à Nadège qui transmettra; Statut Excel : Contacté; Feuille source : écoles', 'excel:reference-contact:2aeffb5bfb6926'),
('Editeur', 'editeur', NULL, NULL, NULL, 'olivier.pille@lerouergue.com', NULL, 'https://www.lerouergue.com/', 'Interlocuteur : Le Rouegue; Prochaine action Excel : envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter; Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:de80c6dfca7dcc'),
('Editions courtes et Longues', 'editeur', NULL, NULL, NULL, 'info@cleditions.com', NULL, 'https://www.cleditions.com/', 'Prochaine action Excel : envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter; Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:5d9e5516c246c6'),
('Eyrolles', 'editeur', NULL, NULL, NULL, 'editeurs_vie_pratique@eyrolles.com', NULL, 'https://www.editions-eyrolles.com/', 'Notes Excel : on a donné 1 ex de G. Sand + flyer; Prochaine action Excel : envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter; Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:2e753b570e2dad'),
('Forum du Livre', 'librairie', '11 rue de la Visitation', '35000', 'Rennes', 'contact@librairieforumdulivre.fr', '02 99 79 38 93', NULL, 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:031877a9c66453'),
('G. Maguet', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:f8003fd9d69067'),
('Géraldine Fontaine', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Site / Réseaux', 'excel:reference-contact:d573a55faadfbe'),
('Gersou Lambert', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:22766b1bb26fe6'),
('Groupe scolaire NDF Stjo |', 'ecole', '26 Rue de Kerpontou, 22260 Pontrieux', NULL, NULL, 'eco22.stjo.pontrieux@e-c.bzh', '02 96 95 61 62', NULL, 'Interlocuteur : Mélina Poulouin; Statut Excel : À contacter; Feuille source : écoles', 'excel:reference-contact:3b112638de8bc0'),
('Gwalarn', 'librairie', '15 rue des Chapeliers,', '22300', 'Lannion', 'librairie.gwalarn@wanadoo.fr', '02 96 37 40 53', 'https://gwalarn.fr/', 'Interlocuteur : Marie-Laure Dudoux; Dernière action Excel : RDV mardi 9/6Marie-Laure Dudoux pour présentation; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:3838468b654b53'),
('Gwenig Le Creurer', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Abonnement', 'excel:reference-contact:7d21c6b92702d5'),
('Hélène Dayan', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:9590b759ba730e'),
('JC Lebeau', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:05b1b96337178a'),
('Jena-Jacques HUET', 'autre', NULL, NULL, NULL, 'JJHUET1@gmail.com', '0620359332', NULL, 'Interlocuteur : Pétrole et argent et musique!; Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:de4076fc490a09'),
('L''Elephant', 'editeur', NULL, NULL, NULL, 'contact@lelephant-larevue.fr', NULL, 'https://lelephant-larevue.fr/', 'Interlocuteur : Jean-Paul ARIF; Notes Excel : on lui a donné Jules Verne/pourquoi pas?; Prochaine action Excel : envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter; Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:c872a0f0db05da'),
('L''histoire vagabonde', 'librairie', '65, rue Ernest Renan', '22220', 'Tréguier', 'l-histoire-vagabonde@orange.fr', '06 26 67 67 77', 'https://www.lhistoirevagabonde.com/', 'Dernière action Excel : Mail envoyé le 3 déc 2025; Notes Excel : libres ancien et occasion; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:1f6a3118f3aa38'),
('La Cédille', 'librairie', '20 Rue de Lourmel', '22400', 'Lamballe', 'contact@la-cedille.fr', '02 96 30 98 51', 'https://la-cedille.fr', 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:46f16098586f4c'),
('La Marmotière éditions', 'editeur', NULL, NULL, NULL, 'editionslamarmotiere@gmail.com', NULL, 'https://www.lamarmotiere-editions.com/', 'Interlocuteur : Raphaelle Rico; Notes Excel : possibilité éventuellemnt d''intégrer nos livres dan sleur collectio à partir de septembre 2027; Prochaine action Excel : envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter; Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:b58c8f282fee80'),
('La Nuit des Temps', 'librairie', '10 quai Émile Zola,', '35000', 'Rennes', 'librairielanuitdestemps@etik.com', '02 99 53 37 95', NULL, 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:3249948ebd06a7'),
('La Plume d''Or', 'librairie', '1 place de l''Église', '22600', 'Loudéac', 'laplumedor.loudeac@gmail.com', '02 96 66 08 26', NULL, 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:47e44cf8642225'),
('La Presse d’Armor', 'presse', NULL, NULL, 'Côtes-d’Armor', 'lapressedarmor@publihebdos.fr', '02 96 55 33 22', NULL, 'Statut Excel : À contacter; Feuille source : Presse locale', 'excel:reference-contact:46e859a76a3d3a'),
('La République des Pyrénées', 'presse', NULL, NULL, 'Pyrénées-Atlantiques', NULL, '–', NULL, 'Contact indiqué dans Excel : – (via site / formulaire); Statut Excel : À contacter; Feuille source : Presse locale', 'excel:reference-contact:e1612c12b58610'),
('L’Astrolabe', 'librairie', '20 place Lucie et Raymond Aubrac', '35000', 'Rennes', NULL, '02 23 06 14 13', NULL, 'Contact indiqué dans Excel : via formulaire; Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:9f47fe85a76a51'),
('Laure Lemoine', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:88a36784682904'),
('Le Bel Aujourd''hui', 'librairie', '19 rue Ernest-Renan', '22220', 'Tréguier', 'librairie@librairie-lba.com', '02 96 92 20 24', 'https://librairie-lba.com/', 'Interlocuteur : Léonie Desbois; Dernière action Excel : Léonie Desbois - appel positif et envoi mail 3/6/2026, relance tél et renvoi un mail le 6/10/2026; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:602fdcfea582ea'),
('LE FANAL', 'librairie', '6, rue Georges Clémenceau', NULL, 'Saiint Quay Portrieux', 'contact@librairie-lefanal.com', '02 96 70 77 52', 'https://www.librairie-lefanal.com/', 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:6e313fc1c225b6'),
('Le Grenier', 'librairie', '6, place Duclos', '22100', 'Dinan', 'contact@librairielegrenier.com', '02.96.39.59.83', NULL, 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:910b871984ed95'),
('Le homard jaune', 'librairie', NULL, NULL, 'Perros', NULL, '02 96 15 90 86', NULL, 'Interlocuteur : Nicolas; Dernière action Excel : Nicolas - appel positif et envoi mail 3/6/2026, relance tél le 6/10 et renvoi mail; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:669c0dd1d38196'),
('Le Penthièvre', 'presse', NULL, NULL, 'Côtes-d’Armor', 'lepenthievre@publihebdos.fr', '02 96 30 80 00', NULL, 'Statut Excel : À contacter; Feuille source : Presse locale', 'excel:reference-contact:f06fce5e25b8b4'),
('Le Petit Bleu des Côtes-d’Armor', 'presse', NULL, NULL, 'Côtes-d’Armor', 'le.petit.bleu@actu.fr', '02 96 39 85 90', NULL, 'Statut Excel : À contacter; Feuille source : Presse locale', 'excel:reference-contact:e810062856da3e'),
('Le Tagarin', 'librairie', NULL, NULL, 'Binic', NULL, NULL, NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:b7f8ea32e6b9b3'),
('Le Télégramme', 'presse', NULL, NULL, 'Bretagne / Côtes-d’Armor', 'telegrammedd@gmail.com / region@letelegramme.fr', '06 07 33 02 70 - 02 98 62 11 33', NULL, 'Statut Excel : À contacter; Feuille source : Presse locale', 'excel:reference-contact:6a1f196e692cc6'),
('Le Trégor', 'presse', NULL, NULL, 'Côtes-d’Armor', 'christophe.ganne@actu.fr / erwann.hirel@actu.fr', '02 96 46 67 67', NULL, 'Statut Excel : À contacter; Feuille source : Presse locale', 'excel:reference-contact:acc95cd55c2e80'),
('Lebeau', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Abonnement', 'excel:reference-contact:90afadb4b8f25c'),
('L’Écho de l’Armor et de l’Argoat', 'presse', NULL, NULL, 'Côtes-d’Armor', 'echo@publihebdos.fr', '02 96 40 62 40', NULL, 'Statut Excel : À contacter; Feuille source : Presse locale', 'excel:reference-contact:03435a693d17a3'),
('Librairie Arcanes', 'librairie', '10, rue de la Gare', '36000', 'Châteauroux', NULL, NULL, NULL, 'Canal d’origine Excel : Librairie', 'excel:reference-contact:ce61899079d4c4'),
('Librairie Ariane', 'librairie', '20 rue Dreyfus', '35000', 'Rennes', NULL, '02 99 79 68 47', NULL, 'Contact indiqué dans Excel : via formulaire; Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:e1362a9faca78b'),
('Librairie Bookstore', 'librairie', '27 rue Gambetta', '64200', 'Biarritz', 'contact@librairiebookstore.com', '05 59 24 00 49', NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:026c6d57e45e93'),
('Librairie Chez Simone', 'librairie', '25 rue Jauréguiberry', '64100', 'Bayonne', 'librairiechezsimone@gmail.com', '05 59 25 73 90', NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:736978e70dc638'),
('Librairie Coiffard', 'librairie', '7-8 Rue de la Fosse', '44000', 'Nantes', 'contact@librairiecoiffard.fr', '02 40 48 16 19', 'https://www.librairiecoiffard.fr/', 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:adbee92b8ebacb'),
('Librairie Du Renard', 'librairie', '8 & 8bis, rue de l’église', '22500', 'Paimpol', 'commandes@librairiedurenard.fr', '0296205459', 'https://librairiedurenard.fr/', 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:b886b34426cd7b'),
('Librairie Hirigoyen', 'librairie', '20 rue Poissonnerie', '64100', 'Bayonne', 'hirigoyen.librairie@wanadoo.fr', '05 59 59 01 22', NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:d4f0bd6ef8e63f'),
('Librairie L''Obèle', 'librairie', '10 rue Pasteur', '22370', 'Pléneuf-Val-André', 'contact@librairielobele.fr', '02 96 71 52 29', NULL, 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:b5a9dfabd1b318'),
('Librairie Le Failler', 'librairie', '8-14 Rue Saint-Georges', '35000', 'Rennes', NULL, '02 99 87 87 87', 'https://www.librairielefailler.fr/', 'Contact indiqué dans Excel : via formulaire; Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:2765c57a213628'),
('Librairie Le Square', 'librairie', '2 place du Foirail', '64120', 'Saint-Palais', 'librairielesquare@gmail.com', '05 59 65 72 36', NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:cb630cfb64f8d8'),
('Librairie L’Écriture', 'librairie', '35 rue de la République', '64500', 'Saint-Jean-de-Luz', 'librairie.lecriture@orange.fr', '05 59 26 17 65', NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:2c0df1969c184c'),
('Librairie Monocle', 'librairie', '16 Pl. de la Liberté,', '22260', 'Pontrieux', NULL, '02 96 92 95 62', NULL, 'Dernière action Excel : visite le 12/02/2026 emballée; Notes Excel : dépot de 8 ex de chaque tome; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:f8fa3f58d42abf'),
('Librairie Mots et Images', 'librairie', '10 rue Saint Yves', '22200', 'Guingamp', 'contact@motsetimages.fr', '02 96 40 08 26', 'https://www.motsetimages.fr/', 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:3d3733b95a9d17'),
('Librairie Tandem', 'librairie', '2 avenue du Général Leclerc', '64000', 'Pau', 'librairie.tandem@wanadoo.fr', '05 59 27 20 70', NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:6ea4405fbd642f'),
('Librairie Tonnet', 'librairie', '25 rue Serviez', '64000', 'Pau', 'contact@librairietonnet.com', '05 59 27 47 00', NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:000738edcea1e6'),
('M-C Lagresle', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:b1c44e5cb21fd9'),
('M''enfin?!', 'librairie', '13 Rue Victor Hugo', '35000', 'Rennes', NULL, '02 99 38 07 83', 'https://www.canalbd.net/librairie-m-enfin/', 'Contact indiqué dans Excel : via formulaire; Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:0f7b9574de24a1'),
('M.Lemoine', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Abonnement', 'excel:reference-contact:c364877a3bbebe'),
('Maire - Marché Montaut', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Salon / Marché', 'excel:reference-contact:95c39e54daa2fe'),
('Marché Montaut septembre 2026', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Salon / Marché', 'excel:reference-contact:85be3137d495ed'),
('Marie Bourgeois', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:6e5599d847757c'),
('Marque-Page', 'librairie', NULL, NULL, 'Quintin', NULL, NULL, NULL, 'Statut Excel : À contacter; Feuille source : communication Librairies', 'excel:reference-contact:3ccac59b67c145'),
('Marsollier-Maurice. A', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:42135956734a76'),
('Mathilde Roger-L', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:b1278fa9d2c47c'),
('Matine', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:a14f86baf77dbd'),
('Mme Jeanine Tanguy', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:56e97754ac034a'),
('Musée de Nantes', 'musee', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Musée', 'excel:reference-contact:c7c7daa068a164'),
('Mylène Voiron', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Abonnement', 'excel:reference-contact:03c6bbbc3db531'),
('Ouest-France (édition locale)', 'presse', NULL, NULL, 'Bretagne', 'redaction.guingamp@ouest-france.fr', '–', NULL, 'Statut Excel : À contacter; Feuille source : Presse locale', 'excel:reference-contact:3926ad88604e85'),
('P-A Lemoine', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Abonnement', 'excel:reference-contact:47e900cdfa0536'),
('Paris-Musées', 'musee', NULL, NULL, NULL, 'marion.assemat@paris.fr', NULL, 'https://www.parismusees.paris.fr/', 'Interlocuteur : Marion Assémat; Notes Excel : a pris Sand et Hugo pour musées/ sera montré aux ocnservaterrus pour validation du contenu/critiqué les prix! tome 1 et 2: 5,50€ et plus 8€; Prochaine action Excel : envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter; Statut Excel : À relancer; Feuille source : CR Salon du livre paris avril 2', 'excel:reference-contact:2e9c2b7f8c9c81'),
('Paroissienne - Marché Montaut', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Salon / Marché', 'excel:reference-contact:b11393539f38e9'),
('Ph. Rompteaux', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:1feff56f11ac2a'),
('Pierre-Alain', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:3dfdd5c42e6498'),
('Régine Seidel', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:5746e7b0cf3f4b'),
('Rouairies Librairie', 'librairie', '15 Rue des Rouairies', '22100', 'Dinan', 'lalibrairiedinan@orange.fr', '02 96 39 04 83', 'https://www.la-librairie-dinan.bzh', 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:807c1920fc9e60'),
('Stan Van Velsen', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:a4721a19d07ef3'),
('Sud Ouest (édition locale)', 'presse', NULL, NULL, 'Pyrénées-Atlantiques', 'ml.ribot@sudouest.fr', '05 35 31 31 31', NULL, 'Statut Excel : À contacter; Feuille source : Presse locale', 'excel:reference-contact:461c8add6b43c4'),
('The Little Bookshop', 'librairie', '7 rue des Fossés', '35000', 'Rennes', 'contact@thelittlebookshop.fr', '06 65 31 41 80', NULL, 'Dernière action Excel : Mail envoyé le 3 déc 2025; Statut Excel : Contacté; Feuille source : communication Librairies', 'excel:reference-contact:b843cba6c32bc4'),
('Tom Librairie', 'librairie', NULL, NULL, 'Perros', NULL, '02 96 91 17 11', NULL, 'Dernière action Excel : appel moyen et envoi mail 3/6/2026; Notes Excel : négatif; Statut Excel : Sans suite; Feuille source : communication Librairies', 'excel:reference-contact:36496a7b9072db'),
('V Lucas', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:da03a87e300c42'),
('Valérie Hélary', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:17f1628bc58926'),
('Valy Lemoine', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Abonnement', 'excel:reference-contact:5221115120d087'),
('Yvette Philippe', 'particulier', NULL, NULL, NULL, NULL, NULL, NULL, 'Canal d’origine Excel : Direct', 'excel:reference-contact:38d28d63221944')
on conflict (source_legacy) where source_legacy is not null do nothing;

insert into public.events (name, event_type, city_region, start_date, end_date, audience, website, organizer, contact_email, notes, follow_up, cost, status, source_legacy) values
('L''Ivre Jeunesse', 'salon', 'Châtillon Saint-Jean', '2025-03-24', '2025-03-29', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Voir fiche sur le site de la Fédération du livre jeunesse
Modalités : Modalités précisées sur la fiche de l’événement
Import initial : feuille 11 EVENEMENTS, ligne 5. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:5'),
('Salon du livre jeunesse Erdre & Gesvres', 'salon', 'Erdre & Gesvres', '2025-03-20', '2025-03-30', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Voir fiche dédiée sur le site de la Fédération
Modalités : Dossier exposant à demander aux organisateurs
Import initial : feuille 11 EVENEMENTS, ligne 6. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:6'),
('Salon du Livre Jeunesse Beaugency (Val de Lire)', 'salon', 'Beaugency', '2025-03-28', '2025-03-30', 'Jeunesse', 'https://www.valdelire.fr/', NULL, NULL, 'Contact / renseignements : Contact via https://www.valdelire.fr/contact
Modalités : Dossier exposant / auteur disponible sur le site
Import initial : feuille 11 EVENEMENTS, ligne 7. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:7'),
('Ramdam - Festival du livre et de la jeunesse', 'salon', 'Wittenheim', '2025-03-29', '2025-03-30', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Coordonnées sur la fiche de la Fédération
Modalités : Inscription via l’organisation locale (Ville / associations)
Import initial : feuille 11 EVENEMENTS, ligne 8. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:8'),
('Quinzaine du livre jeunesse', 'salon', 'Tours', '2025-04-24', '2025-06-16', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Organisation : structures du livre et bibliothèques de Tours
Modalités : Voir conditions professionnelles sur le site ou via la mairie / bibliothèques
Import initial : feuille 11 EVENEMENTS, ligne 9. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:9'),
('Forum du Livre de Saint-Louis', 'salon', 'Saint-Louis (Alsace)', '2025-04-25', '2025-04-27', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Coordonnées sur la fiche de la Fédération
Modalités : Infos exposants communiquées par la ville / association organisatrice
Import initial : feuille 11 EVENEMENTS, ligne 10. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:10'),
('Fête du Livre Jeunesse', 'salon', 'Saint-Paul-Trois-Châteaux', '2025-05-09', '2025-05-11', 'Jeunesse', 'https://www.fetedulivrejeunesse.fr/ (souvent relayé via la Fédération)', NULL, NULL, 'Contact / renseignements : Association du Sou des Écoles – contact via le site ou la page Facebook
Modalités : Candidatures exposants et auteurs à déposer via l’association
Import initial : feuille 11 EVENEMENTS, ligne 11. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:11'),
('Salon du livre jeunesse de Questembert', 'salon', 'Questembert', '2025-05-17', '2025-05-18', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Coordonnées via la fiche de la Fédération
Modalités : Modalités d’inscription à demander à l’organisation locale
Import initial : feuille 11 EVENEMENTS, ligne 12. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:12'),
('Festival du livre jeunesse et de la BD', 'salon', 'Cherbourg', '2025-05-22', '2025-05-25', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Contact via la fiche fédération ou le site de la ville de Cherbourg
Modalités : Espace éditeurs / auteurs, candidature via la ville / association
Import initial : feuille 11 EVENEMENTS, ligne 13. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:13'),
('Faites des livres', 'salon', 'Saint-Junien', '2025-05-23', '2025-05-24', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Contact organisateurs via Fédération ou mairie
Modalités : Conditions précisées chaque année par l’équipe du festival
Import initial : feuille 11 EVENEMENTS, ligne 14. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:14'),
('Salon du Livre Jeunesse', 'salon', 'Magny-en-Vexin', '2025-05-24', '2025-05-24', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Contact sur fiche de la Fédération
Modalités : Inscription via l’équipe organisatrice locale
Import initial : feuille 11 EVENEMENTS, ligne 15. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:15'),
('Salon du livre et de l’illustration jeunesse du Cantal', 'salon', 'Aurillac', '2025-06-12', '2025-06-14', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Contact sur fiche Fédération ou via structures culturelles du Cantal
Modalités : Dossier exposants / auteurs à demander
Import initial : feuille 11 EVENEMENTS, ligne 16. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:16'),
('Festival Rêves d’Océans (livre jeunesse et BD)', 'salon', 'Doëlan – Clohars-Carnoët', '2025-06-14', '2025-06-15', 'Jeunesse', 'https://www.tourismebretagne.com/preparer-mon-sejour/agenda/festival-du-livre-jeunesse-et-bd-reves-doceans-clohars-carnoet-fr-4207856/', NULL, NULL, 'Contact / renseignements : Organisation locale, contact via site tourisme Bretagne ou page Facebook du festival
Modalités : Modalités exposants communiquées directement par les organisateurs
Import initial : feuille 11 EVENEMENTS, ligne 17. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:17'),
('Festival Croq’ les mots, marmot !', 'salon', 'Mayenne', '2025-05-24', '2025-05-25', 'Jeunesse', 'https://www.croqlesmotsmarmot.org/', NULL, NULL, 'Contact / renseignements : Coordination : Mélissa Rouzier – melissa.rouzier@mayennecommunaute.fr / 02 43 30 21 21
Modalités : Appel à projets et modalités exposants via Mayenne Communauté / site du festival
Import initial : feuille 11 EVENEMENTS, ligne 18. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:18'),
('Salon du Livre pour la Jeunesse', 'salon', 'Troyes', '2025-10-09', '2025-10-12', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Coordonnées sur fiche Fédération / site de la ville de Troyes
Modalités : Conditions exposants publiées chaque année
Import initial : feuille 11 EVENEMENTS, ligne 19. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:19'),
('Festival du Livre Jeunesse de Rouen', 'salon', 'Rouen (Halle aux Toiles)', '2025-11-07', '2025-11-09', 'Jeunesse', 'https://www.lismoilesmots.fr/', NULL, NULL, 'Contact / renseignements : Organisation : association Lis-moi les mots – voir site
Modalités : Inscriptions et modalités dans la rubriques professionnels / exposants
Import initial : feuille 11 EVENEMENTS, ligne 20. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:20'),
('Salon du livre jeunesse de Fougères Agglomération', 'salon', 'Fougères', '2025-11-13', '2025-11-16', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Contact via fiche Fédé / agglomération de Fougères
Modalités : Espace éditeurs et animations jeunesse
Import initial : feuille 11 EVENEMENTS, ligne 21. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:21'),
('Salon du Livre Jeunesse en Pays de Morlaix', 'salon', 'Saint-Martin-des-Champs (près de Morlaix)', '2025-11-22', '2025-11-23', 'Jeunesse', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Contact via fiche Fédé et structures du Pays de Morlaix
Modalités : Modalités exposants à demander aux organisateurs
Import initial : feuille 11 EVENEMENTS, ligne 22. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:22'),
('Partir en Livre – grand festival national', 'salon', 'France entière', '2025-07-20', '2025-07-20', 'Jeunesse', 'https://centrenationaldulivre.fr/', NULL, NULL, 'Contact / renseignements : Organisé par le CNL – contacts régionaux via le site du CNL
Modalités : Appels à projets / labellisation pour structures et événements locaux
Import initial : feuille 11 EVENEMENTS, ligne 23. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:23'),
('Schilick on Carnet – Salon de l’illustration jeunesse', 'salon', 'Schiltigheim', '2025-11-14', '2025-11-16', 'Jeunesse (illustration)', 'https://federationlivrejeunesse.fr/', NULL, NULL, 'Contact / renseignements : Organisation : ville de Schiltigheim – contact via site municipal
Modalités : Appel aux illustrateurs / maisons d’édition
Import initial : feuille 11 EVENEMENTS, ligne 24. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:24'),
('Salon du livre et de la presse jeunesse en Seine-Saint-Denis (SLPJ)', 'salon', 'Montreuil', '2025-12-01', '2025-12-01', 'Jeunesse (très grand public)', 'https://slpj.fr/salon/', NULL, NULL, 'Contact / renseignements : Coordonnées via le site, rubrique « Nous contacter »
Modalités : Dossier exposants et billetterie pro : https://slpj.fr/salon/exposants/
Import initial : feuille 11 EVENEMENTS, ligne 25. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:25'),
('Festival du Livre de Colmar', 'salon', 'Colmar', '2025-11-22', '2025-11-23', 'Mixte (généraliste + jeunesse forte)', 'https://www.festivaldulivre.fr/', NULL, NULL, 'Contact / renseignements : Contact via site officiel du Festival du Livre de Colmar
Modalités : Espace jeunesse + stands généralistes, candidatures via le site
Import initial : feuille 11 EVENEMENTS, ligne 26. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:26'),
('Festival Rue des Livres', 'salon', 'Rennes (Cadets de Bretagne)', '2025-03-15', '2025-03-16', 'Mixte (généraliste + jeunesse)', 'https://festival-ruedeslivres.org/', NULL, NULL, 'Contact / renseignements : Via le formulaire de contact du site
Modalités : Espace éditeurs et auteurs, candidature via le site
Import initial : feuille 11 EVENEMENTS, ligne 27. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:27'),
('Festival Rue des Livres (rappel)', 'salon', 'Rennes', '2025-03-15', '2025-03-16', 'Mixte (généraliste + jeunesse)', 'https://festival-ruedeslivres.org/', NULL, NULL, 'Contact / renseignements : Via formulaire de contact
Modalités : Espace éditeurs, librairies, structures, inscription via dossier sur le site
Import initial : feuille 11 EVENEMENTS, ligne 28. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:28'),
('Le Livre sur la Place', 'salon', 'Nancy', '2025-09-12', '2025-09-14', 'Mixte (grand public + jeunesse)', 'https://lelivresurlaplace.nancy.fr/', NULL, NULL, 'Contact / renseignements : Contact : 03 83 85 30 37 (Ville de Nancy)
Modalités : Modalités exposants via la Ville de Nancy / comité organisateur
Import initial : feuille 11 EVENEMENTS, ligne 29. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:29'),
('Fête du Livre de Saint-Étienne', 'salon', 'Saint-Étienne', '2025-10-10', '2025-10-12', 'Mixte (littérature générale & jeunesse)', 'https://fetedulivre.saint-etienne.fr/', NULL, NULL, 'Contact / renseignements : Contact via site (Ville de Saint-Étienne)
Modalités : Infos exposants dans la rubrique professionnels / éditeurs / auteurs
Import initial : feuille 11 EVENEMENTS, ligne 30. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:30'),
('Festival du Livre de Paris', 'salon', 'Paris – Grand Palais', '2025-04-11', '2025-04-13', 'Mixte (tous publics, pôle jeunesse)', 'https://www.festivaldulivredeparis.fr/', NULL, NULL, 'Contact / renseignements : Contact professionnels / exposants via le site (Paris Livres Événements)
Modalités : Tarifs stands et modalités exposants dans la rubrique « exposer »
Import initial : feuille 11 EVENEMENTS, ligne 31. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:31'),
('salon jeunesse Lannion', 'salon', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Contact / renseignements : contact: 07 81 47 65 46 Roselyne Quéré
Modalités : j''ai eu au tél le 6/7 la responsable du salon du livre de Lannion qui a lieu la 1ère semaine de février. Elle n''est pas sûre de refaire le salon car elle a un gros projet pro mais elle est emballée par notre collection et nous prendrai en tout cas avec certitude si le salon a lieu. On a convenu que je la rappelle mi décembre pour en savoir plus
Démarches : mail le 11/06/2026
Import initial : feuille 11 EVENEMENTS, ligne 32. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:32'),
('Festival Rêves d’Océans', 'festival', 'Clohars-Carnoët (Bretagne)', NULL, NULL, 'Jeunesse', NULL, NULL, NULL, 'Période source Excel : Juin
Contact / renseignements : Via mairie ou page Facebook du festival
Modalités : Très bon pour le 5–10 ans, stands éditeurs sur demande
Import initial : feuille 11 EVENEMENTS, ligne 33. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:33'),
('Festival Croq’ les Mots, Marmot', 'festival', 'Mayenne', NULL, NULL, 'Jeunesse', 'https://www.croqlesmotsmarmot.org/', NULL, NULL, 'Période source Excel : Mai
Contact / renseignements : melissa.rouzier@mayennecommunaute.fr
Modalités : Appels à projets éducation + stands éditeurs
Import initial : feuille 11 EVENEMENTS, ligne 34. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:34'),
('Salon du Livre Jeunesse en Pays de Morlaix', 'festival', 'Morlaix', NULL, NULL, 'Jeunesse', NULL, NULL, NULL, 'Période source Excel : Novembre
Contact / renseignements : Via structures culturelles de Morlaix
Modalités : Espace enfants très solide, idéal 5–8 ans
Import initial : feuille 11 EVENEMENTS, ligne 35. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:35'),
('Marché de la BD et du Livre Jeunesse', 'festival', 'Cherbourg', NULL, NULL, 'Jeunesse + BD', NULL, NULL, NULL, 'Période source Excel : Mai
Contact / renseignements : Via mairie de Cherbourg
Modalités : Candidature via association locale ; idéal jeunesse
Import initial : feuille 11 EVENEMENTS, ligne 36. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:36'),
('Livre sur la Place', 'festival', 'Nancy', NULL, NULL, 'Mixte', 'https://lelivresurlaplace.nancy.fr/', NULL, NULL, 'Période source Excel : Début septembre
Contact / renseignements : 03 83 85 30 37 (Ville de Nancy)
Modalités : Espace éditeurs limité ; dépôt candidature avant avril en général
Import initial : feuille 11 EVENEMENTS, ligne 37. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:37'),
('Marché de la Poésie', 'festival', 'Paris – Place Saint-Sulpice', NULL, NULL, 'Mixte', 'https://marche-poesie.com/', NULL, NULL, 'Période source Excel : Juin
Contact / renseignements : contact via site
Modalités : Stands disponibles pour éditeurs indépendants
Import initial : feuille 11 EVENEMENTS, ligne 38. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:38'),
('Comédie du Livre – 10 jours en mai', 'festival', 'Montpellier', NULL, NULL, 'Mixte', NULL, NULL, NULL, 'Période source Excel : Mai
Contact / renseignements : Contact via mairie ou site Comédie du Livre
Modalités : Pôle jeunesse souvent très développé
Import initial : feuille 11 EVENEMENTS, ligne 39. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:39'),
('Marché Noël des Écrivains Bretons', 'festival', 'Bretagne (lieux variables)', NULL, NULL, 'Mixte', NULL, NULL, NULL, 'Période source Excel : Décembre
Contact / renseignements : Via Union des Écrivains Bretons
Modalités : Bon pour les auteurs régionaux et jeunesse
Import initial : feuille 11 EVENEMENTS, ligne 40. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:40'),
('Escale du Livre', 'festival', 'Bordeaux (Gironde)', NULL, NULL, 'Mixte (avec pôle jeunesse)', 'https://escale-livre.com/', NULL, NULL, 'Période source Excel : Début avril
Contact / renseignements : Via formulaire sur site
Modalités : Stands éditeurs disponibles, candidatures sur dossier
Import initial : feuille 11 EVENEMENTS, ligne 41. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:41'),
('Fête du Livre de Bron', 'festival', 'Bron (Lyon)', NULL, NULL, 'Mixte (dont jeunesse)', 'https://www.fetedulivredebron.com/', NULL, NULL, 'Période source Excel : Février
Contact / renseignements : contact via site
Modalités : Sélection éditoriale, peu de stands mais bonne visibilité
Import initial : feuille 11 EVENEMENTS, ligne 42. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:42'),
('Livres en Marches', 'festival', 'Auvergne-Rhône-Alpes', NULL, NULL, 'Mixte (familial)', 'https://livresenmarches.com/', NULL, NULL, 'Période source Excel : Novembre
Contact / renseignements : Via site web
Modalités : Ouvert aux éditeurs, auteurs, illustrateurs
Import initial : feuille 11 EVENEMENTS, ligne 43. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:43'),
('Festival du Livre de Paris', 'festival', 'Paris – Grand Palais', NULL, NULL, 'Mixte (fort pôle jeunesse)', 'https://www.festivaldulivredeparis.fr/', NULL, NULL, 'Période source Excel : 17–19 avril 2026
Contact / renseignements : Via Paris Livres Événements
Modalités : Stands : réservation 6–10 mois avant l''événement
Import initial : feuille 11 EVENEMENTS, ligne 44. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:44'),
('Quais du Polar', 'festival', 'Lyon', NULL, NULL, 'Mixte (polar, BD, jeunesse)', 'https://www.quaisdupolar.com/', NULL, NULL, 'Période source Excel : Fin mars
Contact / renseignements : contact@quaisdupolar.com
Modalités : Sélection d’auteurs / éditeurs ; confirmation après comité
Import initial : feuille 11 EVENEMENTS, ligne 45. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:45'),
('Festival du Livre de Colmar', 'festival', 'Colmar', NULL, NULL, 'Mixte + jeunesse', 'https://www.festivaldulivre.fr/', NULL, NULL, 'Période source Excel : Novembre
Contact / renseignements : Information via site Festival du Livre
Modalités : Espaces illustrateurs / jeunesse
Import initial : feuille 11 EVENEMENTS, ligne 46. Vérifier dates et statut avant décision.', NULL, NULL, 'to_review', 'excel:11 EVENEMENTS:46')
on conflict (source_legacy) where source_legacy is not null do nothing;

insert into public.expenses (expense_date, category, object, supplier, amount, paid_by, payment_method, receipt_reference, status, notes, source_legacy) values
(NULL, 'Impression', 'Tomes 1-4', 'Impression t1-4', 1432.8, 'Armelle', NULL, NULL, 'paid', 'Calcul source financement 2026.; Date absente du fichier source; Source Excel : kipèkoi; ID source : D001', 'excel:06 DEPENSES:D001'),
(NULL, 'Graphiste', 'Tomes 2-7', 'John t2-7', 2260.0, 'Armelle', NULL, NULL, 'paid', 'Calcul source financement 2026.; Date absente du fichier source; Source Excel : kipèkoi; ID source : D002', 'excel:06 DEPENSES:D002'),
(NULL, 'Expédition', 'Divers', 'Envois', 300.0, 'Armelle', NULL, NULL, 'paid', 'Date absente du fichier source; Source Excel : kipèkoi; ID source : D003', 'excel:06 DEPENSES:D003'),
(NULL, 'Graphiste', 'Tome 8', 'John t8', 420.0, 'Armelle', NULL, NULL, 'paid', 'Date absente du fichier source; Source Excel : kipèkoi; ID source : D004', 'excel:06 DEPENSES:D004'),
(NULL, 'Graphiste', 'Tome 9', 'John t9', 420.0, 'Armelle', NULL, NULL, 'paid', 'Date absente du fichier source; Source Excel : kipèkoi; ID source : D005', 'excel:06 DEPENSES:D005'),
(NULL, 'Fournitures', 'Divers', 'Pochettes plastique', 72.6, 'Armelle', NULL, NULL, 'paid', 'Date absente du fichier source; Source Excel : kipèkoi; ID source : D006', 'excel:06 DEPENSES:D006'),
(NULL, 'Graphiste', 'Tome 11', 'John t11', 420.0, 'Armelle', NULL, NULL, 'paid', 'Date absente du fichier source; Source Excel : kipèkoi; ID source : D007', 'excel:06 DEPENSES:D007'),
('2026-04-10', 'Impression', 'Tomes 5-6', 'Impression 5-6', 788.4, 'Vali', NULL, 'FA135340', 'paid', 'Source Excel : kipèkoi; ID source : D008', 'excel:06 DEPENSES:D008'),
(NULL, 'Communication', 'Divers', 'Présentoirs', 88.66, 'Vali', NULL, NULL, 'paid', 'Date absente du fichier source; Source Excel : kipèkoi; ID source : D009', 'excel:06 DEPENSES:D009'),
(NULL, 'Communication', 'Divers', 'Autocollants', 72.95, 'Vali', NULL, NULL, 'paid', '20,23 + 16,90 + 35,82; Date absente du fichier source; Source Excel : kipèkoi; ID source : D010', 'excel:06 DEPENSES:D010'),
(NULL, 'Fournitures', 'Divers', 'Sacs papier', 195.02, 'Vali', NULL, 'VP_3DBC1GZ1', 'paid', 'Date absente du fichier source; Source Excel : kipèkoi; ID source : D011', 'excel:06 DEPENSES:D011'),
(NULL, 'Impression', 'Tomes 7-9 et 11', 'Impression', 2822.4, 'Vali', NULL, 'F-2026-0941', 'paid', 'Réparti en 4 parts dans financement 2026.; Date absente du fichier source; Source Excel : kipèkoi; ID source : D012', 'excel:06 DEPENSES:D012')
on conflict (source_legacy) where source_legacy is not null do nothing;

insert into public.crm_actions (contact_id,action_date,channel,summary,response,next_action,due_date,status,source_legacy) values
((select id from public.contacts where source_legacy='excel:reference-contact:0f7b9574de24a1' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:5'),
((select id from public.contacts where source_legacy='excel:reference-contact:adbee92b8ebacb' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:6'),
((select id from public.contacts where source_legacy='excel:reference-contact:910b871984ed95' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:7'),
((select id from public.contacts where source_legacy='excel:reference-contact:807c1920fc9e60' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:8'),
((select id from public.contacts where source_legacy='excel:reference-contact:3d3733b95a9d17' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:9'),
((select id from public.contacts where source_legacy='excel:reference-contact:1f6a3118f3aa38' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'libres ancien et occasion; Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:10'),
((select id from public.contacts where source_legacy='excel:reference-contact:602fdcfea582ea' limit 1), '2026-06-03', 'autre', 'Léonie Desbois - appel positif et envoi mail 3/6/2026, relance tél et renvoi un mail le 6/10/2026', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:11'),
((select id from public.contacts where source_legacy='excel:reference-contact:3838468b654b53' limit 1), NULL, 'autre', 'RDV mardi 9/6Marie-Laure Dudoux pour présentation', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:12'),
((select id from public.contacts where source_legacy='excel:reference-contact:b5a9dfabd1b318' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:13'),
((select id from public.contacts where source_legacy='excel:reference-contact:b886b34426cd7b' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:14'),
((select id from public.contacts where source_legacy='excel:reference-contact:47e44cf8642225' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:15'),
((select id from public.contacts where source_legacy='excel:reference-contact:3249948ebd06a7' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:16'),
((select id from public.contacts where source_legacy='excel:reference-contact:b843cba6c32bc4' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:17'),
((select id from public.contacts where source_legacy='excel:reference-contact:031877a9c66453' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:18'),
((select id from public.contacts where source_legacy='excel:reference-contact:e1362a9faca78b' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:19'),
((select id from public.contacts where source_legacy='excel:reference-contact:9f47fe85a76a51' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:20'),
((select id from public.contacts where source_legacy='excel:reference-contact:8d21bf76de049c' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:21'),
((select id from public.contacts where source_legacy='excel:reference-contact:2765c57a213628' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:22'),
((select id from public.contacts where source_legacy='excel:reference-contact:6e313fc1c225b6' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:23'),
((select id from public.contacts where source_legacy='excel:reference-contact:f8fa3f58d42abf' limit 1), '2026-02-12', 'autre', 'visite le 12/02/2026 emballée', 'dépot de 8 ex de chaque tome; Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:24'),
((select id from public.contacts where source_legacy='excel:reference-contact:5bcbbaf2301c4d' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:25'),
((select id from public.contacts where source_legacy='excel:reference-contact:b7f8ea32e6b9b3' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:26'),
((select id from public.contacts where source_legacy='excel:reference-contact:669c0dd1d38196' limit 1), '2026-06-03', 'autre', 'Nicolas - appel positif et envoi mail 3/6/2026, relance tél le 6/10 et renvoi mail', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:27'),
((select id from public.contacts where source_legacy='excel:reference-contact:36496a7b9072db' limit 1), '2026-06-03', 'autre', 'appel moyen et envoi mail 3/6/2026', 'négatif; Statut Excel : Sans suite; Source Excel : communication Librairies', NULL, NULL, 'cancelled', 'excel:10 CRM CONTACTS:28'),
((select id from public.contacts where source_legacy='excel:reference-contact:3ccac59b67c145' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:29'),
((select id from public.contacts where source_legacy='excel:reference-contact:46f16098586f4c' limit 1), '2025-12-03', 'autre', 'Mail envoyé le 3 déc 2025', 'Statut Excel : Contacté; Source Excel : communication Librairies', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:30'),
((select id from public.contacts where source_legacy='excel:reference-contact:736978e70dc638' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:32'),
((select id from public.contacts where source_legacy='excel:reference-contact:d4f0bd6ef8e63f' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:33'),
((select id from public.contacts where source_legacy='excel:reference-contact:026c6d57e45e93' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:34'),
((select id from public.contacts where source_legacy='excel:reference-contact:2c0df1969c184c' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:35'),
((select id from public.contacts where source_legacy='excel:reference-contact:6ea4405fbd642f' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:36'),
((select id from public.contacts where source_legacy='excel:reference-contact:000738edcea1e6' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:37'),
((select id from public.contacts where source_legacy='excel:reference-contact:63b667aab8b1bb' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:38'),
((select id from public.contacts where source_legacy='excel:reference-contact:cb630cfb64f8d8' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : communication Librairies', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:39'),
((select id from public.contacts where source_legacy='excel:reference-contact:6a1f196e692cc6' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : Presse locale', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:40'),
((select id from public.contacts where source_legacy='excel:reference-contact:acc95cd55c2e80' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : Presse locale', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:41'),
((select id from public.contacts where source_legacy='excel:reference-contact:e810062856da3e' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : Presse locale', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:42'),
((select id from public.contacts where source_legacy='excel:reference-contact:03435a693d17a3' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : Presse locale', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:43'),
((select id from public.contacts where source_legacy='excel:reference-contact:46e859a76a3d3a' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : Presse locale', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:44'),
((select id from public.contacts where source_legacy='excel:reference-contact:f06fce5e25b8b4' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : Presse locale', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:45'),
((select id from public.contacts where source_legacy='excel:reference-contact:3926ad88604e85' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : Presse locale', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:46'),
((select id from public.contacts where source_legacy='excel:reference-contact:e1612c12b58610' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : Presse locale', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:47'),
((select id from public.contacts where source_legacy='excel:reference-contact:461c8add6b43c4' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : Presse locale', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:48'),
((select id from public.contacts where source_legacy='excel:reference-contact:3b112638de8bc0' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : écoles', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:49'),
((select id from public.contacts where source_legacy='excel:reference-contact:c33fdcf9d6ec15' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À contacter; Source Excel : écoles', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:50'),
((select id from public.contacts where source_legacy='excel:reference-contact:2aeffb5bfb6926' limit 1), '2026-10-05', 'autre', 'envoi le 5/10/2026 comtesse, Molière et Verne par la poste à Nadège qui transmettra', 'Statut Excel : Contacté; Source Excel : écoles', NULL, NULL, 'done', 'excel:10 CRM CONTACTS:51'),
((select id from public.contacts where source_legacy='excel:reference-contact:7aed739991f2a3' limit 1), '2026-04-18', 'autre', 'ok le 18/04/2026', 'font des livres pour les enfants  de 0 à 5 ans/ on lui a donné un flyer , envoyer un mail; Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', NULL, 'planned', 'excel:10 CRM CONTACTS:52'),
((select id from public.contacts where source_legacy='excel:reference-contact:b58c8f282fee80' limit 1), NULL, 'autre', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', 'possibilité éventuellemnt d''intégrer nos livres dan sleur collectio à partir de septembre 2027; Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', NULL, 'planned', 'excel:10 CRM CONTACTS:53'),
((select id from public.contacts where source_legacy='excel:reference-contact:c872a0f0db05da' limit 1), NULL, 'autre', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', 'on lui a donné Jules Verne/pourquoi pas?; Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', NULL, 'planned', 'excel:10 CRM CONTACTS:54'),
((select id from public.contacts where source_legacy='excel:reference-contact:2e753b570e2dad' limit 1), NULL, 'autre', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', 'on a donné 1 ex de G. Sand + flyer; Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', NULL, 'planned', 'excel:10 CRM CONTACTS:55'),
((select id from public.contacts where source_legacy='excel:reference-contact:2e9c2b7f8c9c81' limit 1), NULL, 'autre', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', 'a pris Sand et Hugo pour musées/ sera montré aux ocnservaterrus pour validation du contenu/critiqué les prix! tome 1 et 2: 5,50€ et plus 8€; Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', NULL, 'planned', 'excel:10 CRM CONTACTS:56'),
((select id from public.contacts where source_legacy='excel:reference-contact:45071182135146' limit 1), NULL, 'autre', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', 'Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', NULL, 'planned', 'excel:10 CRM CONTACTS:57'),
((select id from public.contacts where source_legacy='excel:reference-contact:28db993430d747' limit 1), NULL, 'autre', 'envoyer Sand ou Jules Verne (Amélie)', 'Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', 'envoyer Sand ou Jules Verne (Amélie)', NULL, 'planned', 'excel:10 CRM CONTACTS:58'),
((select id from public.contacts where source_legacy='excel:reference-contact:de80c6dfca7dcc' limit 1), NULL, 'autre', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', 'Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', NULL, 'planned', 'excel:10 CRM CONTACTS:59'),
((select id from public.contacts where source_legacy='excel:reference-contact:54ed29c3576ef3' limit 1), NULL, 'autre', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', 'Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', NULL, 'planned', 'excel:10 CRM CONTACTS:60'),
((select id from public.contacts where source_legacy='excel:reference-contact:5d9e5516c246c6' limit 1), NULL, 'autre', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', 'Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', 'envoyer mail de remerciement de l''accueil au salon avec flyer et Proust à feuilleter', NULL, 'planned', 'excel:10 CRM CONTACTS:61'),
((select id from public.contacts where source_legacy='excel:reference-contact:de4076fc490a09' limit 1), NULL, 'autre', 'Suivi commercial repris du classeur Excel', 'Statut Excel : À relancer; Source Excel : CR Salon du livre paris avril 2', NULL, NULL, 'planned', 'excel:10 CRM CONTACTS:66')
on conflict (source_legacy) where source_legacy is not null do nothing;

commit;

-- Vérification des données chargées
select 'livres' as table_name, count(*)::bigint as lignes from public.books
union all select 'contacts',count(*) from public.contacts
union all select 'événements',count(*) from public.events
union all select 'dépenses',count(*) from public.expenses
union all select 'actions CRM',count(*) from public.crm_actions
;

-- Les historiques de ventes, commandes, paiements et mouvements sont conservés en staging Excel :
-- ils ne sont pas convertis automatiquement en écritures opérationnelles tant que les ambiguïtés ne sont pas rapprochées.